from b import *
pro.menu.add_command(label='exit',command=pro.app.destroy)
"""#.+"""